##################
Backrooms - v0.1.0
##################

********
Warning!
********
Backrooms is still in Development Status Alpha!
This means backwards compatibility break can and will happen!
The core idea of the language has been laid out but expect rules “instructions" to change.
Also some rules have not been implement yet.


*****
About
*****
This python module "backrooms" is an `Esolang <https://esolangs.org/wiki/Main_Page>`_.

backrooms was inspired by:
    * backrooms Creepypasta/MEME
    * ASCIIDOTS Esolang
    * CISC Architecture

Backrooms was designed to be:
    * hackable VIA memory overflow attacks, poor error handling, ect.
    * visually pleasing.
    * enjoy able to write small/medium programs.
    * capable to rewrite all of a program at run-time.
