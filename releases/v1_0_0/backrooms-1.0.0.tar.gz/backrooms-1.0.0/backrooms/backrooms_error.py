"""
Copyright 2021 Charles McMarrow

This script base exception to backrooms.
"""


class BackroomsError(Exception):
    pass
