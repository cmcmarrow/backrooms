"""
Copyright 2021 Charles McMarrow
"""


class BackroomsError(Exception):
    pass
